import { Client, Storage, Databases, ID, Query } from "node-appwrite";
import * as fs from "fs";
import * as path from "path";

// Appwrite Configuration
const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";
const PROJECT_ID = "696f6e31002241c92438";
const ENDPOINT = "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = "aiml-club-db";
const MEMBERS_COLLECTION = "members";
const BUCKET_ID = "team-members";
const IMAGES_DIR = "C:\\Users\\Umesh\\Downloads\\Untitled design (1)";

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const storage = new Storage(client);
const databases = new Databases(client);

async function main() {
    console.log("🚀 Starting member image sync...\n");

    try {
        // 1. Get all members from database
        console.log("📡 Fetching members from database...");
        const membersResponse = await databases.listDocuments(DATABASE_ID, MEMBERS_COLLECTION, [Query.limit(200)]);
        const members = membersResponse.documents;
        console.log(`✅ Found ${members.length} members in database.\n`);

        // 2. Read local images
        if (!fs.existsSync(IMAGES_DIR)) {
            console.error(`❌ Directory not found: ${IMAGES_DIR}`);
            return;
        }
        const files = fs.readdirSync(IMAGES_DIR);
        console.log(`📂 Found ${files.length} files in local directory.\n`);

        let updatedCount = 0;
        let uploadCount = 0;

        for (const file of files) {
            const ext = path.extname(file).toLowerCase();
            if (![".jpg", ".jpeg", ".png", ".webp"].includes(ext)) continue;

            const fileName = path.parse(file).name;
            const filePath = path.join(IMAGES_DIR, file);

            // Find matching member
            // Exact match, partial match, or common spelling variation (Aanya vs Ananya)
            const matchingMember = members.find(m => {
                const memberName = m.name.toLowerCase().replace(/\s/g, "");
                const searchName = fileName.toLowerCase().replace(/\s/g, "");

                // Direct match or inclusion
                if (memberName === searchName || memberName.includes(searchName) || searchName.includes(memberName)) {
                    return true;
                }

                // Handle Aanya / Ananya specifically or general fuzzy
                if ((memberName.includes("aanya") && searchName.includes("ananya")) ||
                    (memberName.includes("ananya") && searchName.includes("aanya"))) {
                    return true;
                }

                return false;
            });

            if (!matchingMember) {
                console.log(`⏭️  No matching member found for file: ${file}`);
                continue;
            }

            console.log(`📤 Syncing image for: ${matchingMember.name} (File: ${file})`);

            try {
                // Upload to Storage
                const fileBuffer = fs.readFileSync(filePath);
                const mimeType = ext === ".png" ? "image/png" : "image/jpeg";
                const blob = new Blob([fileBuffer], { type: mimeType });
                const inputFile = new File([blob], file, { type: mimeType });

                const uploadedFile = await storage.createFile(BUCKET_ID, ID.unique(), inputFile);
                uploadCount++;

                const imageUrl = `${ENDPOINT}/storage/buckets/${BUCKET_ID}/files/${uploadedFile.$id}/view?project=${PROJECT_ID}`;

                // Update Database
                await databases.updateDocument(
                    DATABASE_ID,
                    MEMBERS_COLLECTION,
                    matchingMember.$id,
                    {
                        imageId: uploadedFile.$id,
                        imageUrl: imageUrl
                    }
                );

                console.log(`✅ Successfully updated ${matchingMember.name}`);
                updatedCount++;
            } catch (error) {
                console.error(`❌ Failed to sync ${matchingMember.name}:`, error);
            }
        }

        console.log(`\n✨ Sync complete!`);
        console.log(`📊 Uploaded ${uploadCount} images, Updated ${updatedCount} members.`);

    } catch (error) {
        console.error("❌ Fatal Error:", error);
    }
}

main();
