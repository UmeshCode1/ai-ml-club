
import { Client, Databases, Query } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";
const PROJECT_ID = "696f6e31002241c92438";
const DATABASE_ID = "aiml-club-db";
const COLLECTION_ID = "members";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);

async function main() {
    console.log("🔍 Verifying team photos...\n");

    const membersList = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_ID,
        [Query.limit(100)]
    );
    const members = membersList.documents;

    let haveImage = 0;
    let noImage = 0;

    console.log("--- Members WITHOUT Image ---");
    for (const member of members) {
        if (member.imageId) {
            haveImage++;
        } else {
            noImage++;
            console.log(`❌ ${member.name} (${member.role})`);
        }
    }

    console.log("\n--- Summary ---");
    console.log(`✅ Members with image: ${haveImage}`);
    console.log(`❌ Members without image: ${noImage}`);
    console.log(`Total members: ${members.length}`);
}

main();
