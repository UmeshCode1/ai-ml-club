// Debug: Test creating a subscription directly
// Run with: npx tsx scripts/test-subscription.ts

import { Client, Databases, ID } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";
const COLLECTION_ID = "subscriptions";

async function main() {
    console.log("🔍 Testing subscription creation...\n");

    try {
        // Try to create a test document
        const result = await databases.createDocument(
            DATABASE_ID,
            COLLECTION_ID,
            ID.unique(),
            {
                name: "Test User",
                email: "test@example.com"
            }
        );
        console.log("✅ Document created successfully!");
        console.log("Document ID:", result.$id);

        // Clean up - delete the test document
        await databases.deleteDocument(DATABASE_ID, COLLECTION_ID, result.$id);
        console.log("🧹 Test document deleted");

    } catch (error: unknown) {
        const err = error as { message?: string; code?: number; type?: string };
        console.error("❌ Error creating document:");
        console.error("  Code:", err.code);
        console.error("  Type:", err.type);
        console.error("  Message:", err.message);
    }
}

main();
