import { Client, Databases, ID, AppwriteException } from "node-appwrite";
import * as dotenv from "dotenv";
import * as path from "path";
import * as fs from "fs";

// Load environment variables
dotenv.config({ path: path.resolve(process.cwd(), ".env.local") });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

if (!API_KEY) {
    console.error("APPWRITE_API_KEY is missing in .env.local");
    process.exit(1);
}

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);

// Helper to convert local image paths to valid URLs for Appwrite validation
const toValidUrl = (path: string) => {
    if (path.startsWith("http")) return path;
    return `https://aimlclub.tech${path}`;
};

// Data to seed
const galleryAlbums = [
    {
        eventName: "Expert Talk - Coding Thinker",
        description: "Insightful session on coding practices and tech industry insights",
        posterUrl: toValidUrl("/images/events/expert-talk.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-08-26",
        category: "Expert Talk",
        photoCount: 15,
        isVisible: true,
    }
];

async function seed() {
    console.log("Starting debug seeding...");

    const album = galleryAlbums[0];
    try {
        console.log(`Trying to create album: ${album.eventName}`);
        await databases.createDocument(DATABASE_ID, "gallery", ID.unique(), album);
        console.log("✓ Success!");
    } catch (err: any) {
        if (err instanceof AppwriteException || err.response) {
            fs.writeFileSync('scripts/error-log.json', JSON.stringify(err.response || err, null, 2));
            console.log("Error saved to scripts/error-log.json");
        } else {
            console.error("✗ Unknown Error:", err);
        }
    }
}

seed().catch(console.error);
