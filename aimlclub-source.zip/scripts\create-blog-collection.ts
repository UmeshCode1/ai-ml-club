/**
 * Script to create the Blog collection in Appwrite
 * Run with: npx ts-node scripts/create-blog-collection.ts
 */

import { Client, Databases, Permission, Role } from "node-appwrite";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

if (!API_KEY) {
    console.error("❌ APPWRITE_API_KEY not found in .env.local");
    process.exit(1);
}

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);

const COLLECTION_ID = "blog";

async function createBlogCollection() {
    console.log("🚀 Creating Blog collection...\n");

    try {
        // Try to delete existing collection first
        try {
            await databases.deleteCollection(DATABASE_ID, COLLECTION_ID);
            console.log("🗑️  Deleted existing blog collection");
        } catch {
            console.log("📁 No existing blog collection found");
        }

        // Create new collection
        await databases.createCollection(
            DATABASE_ID,
            COLLECTION_ID,
            "Blog Posts",
            [
                Permission.read(Role.any()),
                Permission.create(Role.users()),
                Permission.update(Role.users()),
                Permission.delete(Role.users()),
            ]
        );
        console.log("✅ Created blog collection");

        // Create attributes
        const attributes = [
            { name: "title", type: "string", size: 255, required: true },
            { name: "slug", type: "string", size: 255, required: true },
            { name: "excerpt", type: "string", size: 500, required: true },
            { name: "content", type: "string", size: 50000, required: true },
            { name: "author", type: "string", size: 100, required: true },
            { name: "authorRole", type: "string", size: 100, required: false },
            { name: "authorAvatar", type: "url", required: false },
            { name: "coverImageUrl", type: "url", required: false },
            { name: "category", type: "string", size: 50, required: false },
            { name: "tags", type: "string", size: 255, required: false },
            { name: "readTime", type: "integer", required: false, min: 1, max: 60, default: 5 },
            { name: "isPublished", type: "boolean", required: false, default: false },
            { name: "isFeatured", type: "boolean", required: false, default: false },
            { name: "publishedAt", type: "string", size: 50, required: false },
        ];

        for (const attr of attributes) {
            try {
                if (attr.type === "string") {
                    await databases.createStringAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.size!,
                        attr.required
                    );
                } else if (attr.type === "url") {
                    await databases.createUrlAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.required
                    );
                } else if (attr.type === "integer") {
                    await databases.createIntegerAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.required,
                        attr.min,
                        attr.max,
                        attr.default
                    );
                } else if (attr.type === "boolean") {
                    await databases.createBooleanAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.required,
                        attr.default
                    );
                }
                console.log(`  ✅ Created attribute: ${attr.name}`);
            } catch (error: unknown) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                console.log(`  ⚠️  Attribute ${attr.name}: ${errorMessage}`);
            }
        }

        // Wait for attributes to be ready
        console.log("\n⏳ Waiting for attributes to be ready...");
        await new Promise(resolve => setTimeout(resolve, 4000));

        // Create indexes
        const indexes = [
            { key: "slug_idx", attributes: ["slug"] },
            { key: "isPublished_idx", attributes: ["isPublished"] },
            { key: "category_idx", attributes: ["category"] },
        ];

        for (const idx of indexes) {
            try {
                await databases.createIndex(
                    DATABASE_ID,
                    COLLECTION_ID,
                    idx.key,
                    "key",
                    idx.attributes
                );
                console.log(`✅ Created index: ${idx.key}`);
            } catch (error: unknown) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                console.log(`⚠️  Index ${idx.key}: ${errorMessage}`);
            }
        }

        console.log("\n🎉 Blog collection created successfully!");
        console.log("\n📝 Collection Schema:");
        console.log("   - title (string, required): Blog post title");
        console.log("   - slug (string, required): URL-friendly slug");
        console.log("   - excerpt (string, required): Short description");
        console.log("   - content (string, required): Full blog content (markdown)");
        console.log("   - author (string, required): Author name");
        console.log("   - authorRole (string): Author's role/title");
        console.log("   - authorAvatar (url): Author's avatar image");
        console.log("   - coverImageUrl (url): Cover image URL");
        console.log("   - category (string): Category (AI, ML, Web Dev, Events, etc.)");
        console.log("   - tags (string): Comma-separated tags");
        console.log("   - readTime (integer): Estimated read time in minutes");
        console.log("   - isPublished (boolean): Published status (default: false)");
        console.log("   - isFeatured (boolean): Featured on homepage (default: false)");
        console.log("   - publishedAt (string): Publication date");

    } catch (error) {
        console.error("❌ Error creating collection:", error);
    }
}

createBlogCollection();
