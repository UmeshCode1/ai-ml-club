// Add phone attribute to contacts and suggestions collections
// Run with: npx tsx scripts/add-phone-to-forms.ts

import { Client, Databases } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";

async function addPhoneAttribute(collectionId: string, collectionName: string) {
    try {
        await databases.createStringAttribute(
            DATABASE_ID,
            collectionId,
            "phone",
            20,      // Max length for phone number
            false    // NOT required (optional)
        );
        console.log(`✅ Added phone attribute to ${collectionName}`);
    } catch (error: unknown) {
        const err = error as { message?: string; code?: number };
        if (err.code === 409) {
            console.log(`ℹ️ Phone attribute already exists in ${collectionName}`);
        } else {
            console.error(`❌ Error adding to ${collectionName}:`, err.message);
        }
    }
}

async function main() {
    console.log("📱 Adding phone attribute to collections...\n");

    await addPhoneAttribute("contacts", "Contacts");
    await addPhoneAttribute("suggestions", "Suggestions");

    console.log("\n✨ Done!");
}

main();
