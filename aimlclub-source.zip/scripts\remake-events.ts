import { Client, Databases, Permission, Role } from "node-appwrite";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY || "");

const databases = new Databases(client);

async function create() {
    console.log("RE-CREATING EVENTS COLLECTION...");
    try {
        try { await databases.deleteCollection(DATABASE_ID, "events"); } catch { }
        await databases.createCollection(DATABASE_ID, "events", "Events", [Permission.read(Role.any())]);

        console.log("Adding attributes with 2s delay...");

        const attrs = [
            { name: "title", type: "string", size: 255, required: true },
            { name: "description", type: "string", size: 2000, required: true },
            { name: "date", type: "string", size: 50, required: true },
            { name: "isUpcoming", type: "boolean", required: true, default: false },
            { name: "venue", type: "string", size: 255, required: false },
            { name: "location", type: "string", size: 255, required: false },
            { name: "imageUrl", type: "string", size: 500, required: false },
            { name: "registrationLink", type: "string", size: 500, required: false },
            { name: "category", type: "string", size: 100, required: false },
            { name: "duration", type: "string", size: 100, required: false },
            { name: "status", type: "string", size: 50, required: false },
        ];

        for (const attr of attrs) {
            if (attr.type === "string") {
                await databases.createStringAttribute(DATABASE_ID, "events", attr.name, attr.size!, attr.required);
            } else if (attr.type === "boolean") {
                await databases.createBooleanAttribute(DATABASE_ID, "events", attr.name, attr.required);
            }
            console.log("✅ " + attr.name);
            await new Promise(r => setTimeout(r, 2000));
        }

        console.log("WAITING 10s for stability...");
        await new Promise(r => setTimeout(r, 10000));
        console.log("DONE");
    } catch (e: unknown) {
        if (e instanceof Error) {
            console.error(e.message);
        } else {
            console.error("An unknown error occurred");
        }
    }
}

create();
