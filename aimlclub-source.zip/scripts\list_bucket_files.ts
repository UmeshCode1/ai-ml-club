
import { Client, Storage, Query } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";
const PROJECT_ID = "696f6e31002241c92438";
const BUCKET_ID = "team-members";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const storage = new Storage(client);

async function main() {
    console.log("📂 Listing all storage files...\n");

    try {
        let allFiles = [];
        let limit = 100;
        let offset = 0;

        while (true) {
            const response = await storage.listFiles(
                BUCKET_ID,
                [Query.limit(limit), Query.offset(offset)]
            );
            allFiles = [...allFiles, ...response.files];
            if (response.files.length < limit) break;
            offset += limit;
        }

        console.log(`✅ Total files: ${allFiles.length}`);
        console.log("--- Filenames ---");
        allFiles.forEach(f => console.log(f.name));

    } catch (err: any) {
        console.error("❌ Error:", err.message);
    }
}

main();
