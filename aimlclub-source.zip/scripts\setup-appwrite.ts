// Final setup script - adds ALL required attributes and seeds data
// Run with: npx tsx scripts/setup-appwrite.ts

import { Client, Databases, Permission, Role, ID } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";

async function addAllMemberAttributes() {
    console.log("📝 Adding ALL member attributes...\n");

    const stringAttrs = [
        { key: "name", size: 100, required: true },
        { key: "role", size: 100, required: true },
        { key: "team", size: 100, required: true },
        { key: "enrollmentNo", size: 30, required: false },
        { key: "contactNo", size: 20, required: false },
        { key: "linkedin", size: 300, required: false },
        { key: "github", size: 300, required: false },
        { key: "imageUrl", size: 500, required: false },
    ];

    for (const attr of stringAttrs) {
        try {
            await databases.createStringAttribute(DATABASE_ID, "members", attr.key, attr.size, attr.required);
            console.log(`✅ ${attr.key}`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  ${attr.key} exists`);
            } else {
                console.log(`❌ ${attr.key}: ${err.message}`);
            }
        }
    }

    // Email attribute
    try {
        await databases.createEmailAttribute(DATABASE_ID, "members", "email", true);
        console.log(`✅ email`);
    } catch (error: unknown) {
        const err = error as Error;
        if (err.message.includes("already exists")) {
            console.log(`⏭️  email exists`);
        } else {
            console.log(`❌ email: ${err.message}`);
        }
    }
}

async function wait(ms: number) {
    console.log(`\n⏳ Waiting ${ms / 1000}s for Appwrite to process attributes...`);
    await new Promise(r => setTimeout(r, ms));
}

interface TeamMember {
    name: string;
    enrollmentNo?: string;
    role: string;
    team: string;
    contactNo?: string;
    email: string;
    linkedin?: string;
    github?: string;
    imageUrl?: string;
}

const teamMembers: TeamMember[] = [
    // FACULTY
    { name: "Prof. Shamaila Khan", role: "Faculty Coordinator", team: "Faculty", email: "shamailakhan@oriental.ac.in" },
    // CORE
    { name: "Vishal Kumar", enrollmentNo: "0126AL231142", role: "President", team: "Core Leadership", contactNo: "6299200082", email: "vg8904937@gmail.com" },
    { name: "Umesh Patel", enrollmentNo: "0126AL231140", role: "Vice President", team: "Core Leadership", contactNo: "7974389476", email: "umesh.code1@gmail.com", linkedin: "https://linkedin.com/in/umesh-patel-5647b42a4", github: "https://github.com/UmeshCode1" },
    // EVENT
    { name: "Gourav Jain", enrollmentNo: "0126AL231055", role: "Event Head", team: "Event & Operations", contactNo: "8878094508", email: "gjain9279@gmail.com" },
    { name: "Aarchi Sharma", enrollmentNo: "0126AL231001", role: "Event Head", team: "Event & Operations", contactNo: "6266091145", email: "aarchisharma320@gmail.com" },
    { name: "Parul Ajit", enrollmentNo: "0126AL231092", role: "Event Head", team: "Event & Operations", contactNo: "8602691174", email: "parulajit907@gmail.com" },
    { name: "Anjali Sonare", enrollmentNo: "0126AL241015", role: "Event Team Member", team: "Event & Operations", contactNo: "9201724696", email: "anjailsonare780@gmail.com" },
    { name: "Aanya Tomar", enrollmentNo: "0126AL241023", role: "Event Team Member", team: "Event & Operations", contactNo: "9770342084", email: "tomaraanya671@gmail.com" },
    { name: "Bhavesh Singh", enrollmentNo: "0126AL231048", role: "Event Team Member", team: "Event & Operations", contactNo: "9516686603", email: "bhaveshsinpanwar15@gmail.com" },
    { name: "Tanu Jadon", enrollmentNo: "0126AL241132", role: "Event Team Member", team: "Event & Operations", contactNo: "6264052784", email: "tanu05624@gmail.com" },
    { name: "Sarvesh Sejwar", enrollmentNo: "0126AL253D18", role: "Event Team Member", team: "Event & Operations", contactNo: "9329441246", email: "sarveshsejwar441@gmail.com" },
    { name: "Nasir Khan", enrollmentNo: "0126AL241068", role: "Event Team Member", team: "Event & Operations", contactNo: "7898009433", email: "mdnasir078667@gmail.com" },
    { name: "Rinki Pathak", enrollmentNo: "0126AL241096", role: "Event Team Member", team: "Event & Operations", contactNo: "9644179155", email: "rinkipathak255@gmail.com" },
    // DISCIPLINE
    { name: "Prince Kumar", enrollmentNo: "0126AL231101", role: "Discipline Head", team: "Discipline", contactNo: "9470280758", email: "princekumar2012010@gmail.com" },
    { name: "Nikhil Singh", enrollmentNo: "0126AL231088", role: "Discipline Team Member", team: "Discipline", contactNo: "9244387773", email: "nikhilssingh22@gmail.com" },
    { name: "Himanshu Gour", enrollmentNo: "0126AL231062", role: "Discipline Team Member", team: "Discipline", contactNo: "9669289659", email: "himanshugour7@gmail.com" },
    { name: "Sarthak Shrivastava", enrollmentNo: "0126AL231120", role: "Discipline Team Member", team: "Discipline", contactNo: "9285330586", email: "shrivastavasarthak2006@gmail.com" },
    // TECHNICAL
    { name: "Kinshuk Verma", enrollmentNo: "0126AL231076", role: "Tech Lead", team: "Technical", contactNo: "9094359829", email: "ver.kinshuk111@gmail.com" },
    { name: "Nimisha Kumari", enrollmentNo: "0126AL231089", role: "Tech Team Member", team: "Technical", contactNo: "8982849203", email: "nimishakum511@gmail.com" },
    { name: "Arnav Singh", enrollmentNo: "0126AL241026", role: "Tech Team Member", team: "Technical", contactNo: "8234099782", email: "sigh67arnav@gmail.com" },
    { name: "Himanshu Singh", enrollmentNo: "0126AL241048", role: "Tech Team Member", team: "Technical", contactNo: "8815218904", email: "singhhimmanshu9893@gmail.com" },
    { name: "Jitesh", enrollmentNo: "0126AL241051", role: "Tech Team Member", team: "Technical", contactNo: "8817683880", email: "jiteshverma139@gmail.com" },
    // ANCHORS
    { name: "Heer", enrollmentNo: "0126AL231061", role: "Anchors Head", team: "Anchors & Stage", contactNo: "8966061631", email: "heermurjani2004@gmail.com" },
    { name: "Anshul Sharma", enrollmentNo: "0126AL231025", role: "Anchors Head", team: "Anchors & Stage", contactNo: "6263941427", email: "anshulsharma008a@gmail.com" },
    { name: "Ayush Tamrakar", enrollmentNo: "0126AL231045", role: "Anchor", team: "Anchors & Stage", contactNo: "8871917308", email: "tamrakarsudha272@gmail.com" },
    { name: "Avni Rawat", enrollmentNo: "0126AL241032", role: "Anchor", team: "Anchors & Stage", contactNo: "8450896733", email: "avnir361@gmail.com" },
    { name: "Ankit Sharma", enrollmentNo: "0126AL241016", role: "Anchor", team: "Anchors & Stage", contactNo: "7724904911", email: "ankitsharma60784@gmail.com" },
    { name: "Apurvi Aggarwal", enrollmentNo: "0126AL241024", role: "Anchor", team: "Anchors & Stage", contactNo: "7389176728", email: "agrawalapurvi96@gmail.com" },
    { name: "Shambhavi", enrollmentNo: "0126AL241111", role: "Anchor", team: "Anchors & Stage", contactNo: "9993418752", email: "shambhavim57@gmail.com" },
    { name: "Manish Mehra", enrollmentNo: "0126AL241059", role: "Anchor", team: "Anchors & Stage", contactNo: "8966070097", email: "manishmehra8966@gmail.com" },
    // PR
    { name: "Prakhar Sahu", enrollmentNo: "0126AL231098", role: "Public Relations", team: "Media - PR", contactNo: "9584060146", email: "prakharsahu150@gmail.com" },
    { name: "Khushi Kumari", enrollmentNo: "0126AL231075", role: "Media Head", team: "Media - PR", contactNo: "8789498277", email: "khushikumari89934@gmail.com" },
    { name: "Anushka Malviya", enrollmentNo: "0126AL241021", role: "Media Associate", team: "Media - PR", contactNo: "9752099722", email: "anushkamalviya93@gmail.com" },
    { name: "Aashu Kumar", enrollmentNo: "0126AL241001", role: "Media Associate", team: "Media - PR", contactNo: "8102823110", email: "kaviraj07310731@gmail.com" },
    // DESIGN
    { name: "Daksh Sahni", enrollmentNo: "0126AL241036", role: "Graphics Designer", team: "Media - Design", contactNo: "9696532552", email: "dakshsahni2006@gmail.com" },
    { name: "Pritish Mandal", enrollmentNo: "0126AL231102", role: "Graphics Designer", team: "Media - Design", contactNo: "7067963041", email: "pritishkumar28@gmail.com" },
    { name: "Abhijeet Sarkar", enrollmentNo: "0126AL231004", role: "Graphics Designer", team: "Media - Design", contactNo: "9111900236", email: "abhiztsarkar@gmail.com" },
    { name: "Hana Nafees Abbasi", enrollmentNo: "0126AL241043", role: "Graphics Designer", team: "Media - Design", contactNo: "7909796744", email: "hananafees16@gmail.com" },
    { name: "Mohammed Arif Zaidi", enrollmentNo: "0126AL241062", role: "Graphics Designer", team: "Media - Design", contactNo: "8226042706", email: "arifzaidi072@gmail.com" },
    // EDITORS
    { name: "Rajeev Kumar", enrollmentNo: "0126AL241093", role: "Media Member", team: "Media - Editors", contactNo: "9798512385", email: "raj1807600@gmail.com" },
    { name: "Aditya Rajput", enrollmentNo: "0126AL241004", role: "Media Member", team: "Media - Editors", contactNo: "9006984884", email: "adityacreative64@gmail.com" },
    { name: "Prince Khatik", enrollmentNo: "0126AL251047", role: "Media Member", team: "Media - Editors", contactNo: "6269399193", email: "princekhatik7612@gmail.com" },
    { name: "Teena Nandanwar", enrollmentNo: "0126CS251346", role: "Media Member", team: "Media - Editors", contactNo: "9993016677", email: "nandanwarteena@gmail.com" },
];

async function seedMembers() {
    console.log("\n🚀 Seeding team members...\n");
    let added = 0, errors = 0;

    for (const member of teamMembers) {
        try {
            await databases.createDocument(DATABASE_ID, "members", ID.unique(), member, [Permission.read(Role.any())]);
            console.log(`✅ ${member.name}`);
            added++;
        } catch (error: unknown) {
            const err = error as Error;
            console.error(`❌ ${member.name}: ${err.message.slice(0, 50)}`);
            errors++;
        }
    }
    console.log(`\n📊 Results: ✅ ${added} | ❌ ${errors}`);
}

async function main() {
    console.log("🔧 AIML Club - Full Appwrite Setup\n");
    console.log("====================================\n");

    await addAllMemberAttributes();
    await wait(10000); // Wait 10 seconds for attributes to be created
    await seedMembers();

    console.log("\n====================================");
    console.log("✨ Complete!");
}

main().catch(console.error);
