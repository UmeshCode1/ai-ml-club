// Add correct 2024-25 team members (as specified by user)
// First delete wrong entries, then add correct ones
// Run with: npx tsx scripts/fix-old-year-members.ts

import { Client, Databases, Query, ID } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";

// Correct 2024-25 team members (as specified by user)
const OLD_YEAR_NAMES = [
    "Vishal Kumar",
    "Umesh Patel",
    "Prakhar Sahu",
    "Aarchi Sharma",
    "Parul Ajit",
    "Gourav Jain",
    "Kinshuk Verma",
    "Prince Kumar",
    "Anshul Sharma",
    "Heer",
    "Khushi Kumari",
    "Prof. Shamaila Khan"  // Faculty
];

async function main() {
    console.log("🔧 Fixing 2024-25 team members...\n");

    // Step 1: Delete all 2024-25 entries (wrong ones we added earlier)
    console.log("🗑️  Deleting incorrect 2024-25 entries...");
    let offset = 0;
    let hasMore = true;
    let deleted = 0;

    while (hasMore) {
        const response = await databases.listDocuments(DATABASE_ID, "members", [
            Query.equal("year", "2024-25"),
            Query.limit(100),
            Query.offset(offset)
        ]);

        for (const doc of response.documents) {
            try {
                await databases.deleteDocument(DATABASE_ID, "members", doc.$id);
                console.log(`   Deleted: ${doc.name}`);
                deleted++;
            } catch (e) {
                // ignore
            }
        }

        hasMore = response.documents.length === 100;
        offset += response.documents.length;
    }
    console.log(`   Deleted ${deleted} incorrect entries\n`);

    // Step 2: Get current members (2025-26) and copy specified ones to 2024-25
    console.log("📝 Adding correct 2024-25 team members...");
    let added = 0;

    const allMembers = await databases.listDocuments(DATABASE_ID, "members", [
        Query.limit(100)
    ]);

    for (const member of allMembers.documents) {
        // Check if this member should be in 2024-25 list
        const shouldInclude = OLD_YEAR_NAMES.some(name =>
            member.name.toLowerCase().includes(name.toLowerCase()) ||
            name.toLowerCase().includes(member.name.toLowerCase())
        );

        if (shouldInclude) {
            try {
                await databases.createDocument(DATABASE_ID, "members", ID.unique(), {
                    name: member.name,
                    role: member.role,
                    team: member.team,
                    email: member.email || "",
                    enrollmentNo: member.enrollmentNo || "",
                    linkedin: member.linkedin || "",
                    github: member.github || "",
                    instagram: member.instagram || "",
                    imageUrl: member.imageUrl || "",
                    year: "2024-25",
                    status: "active"
                });
                console.log(`✅ ${member.name} (${member.role})`);
                added++;
            } catch (error: unknown) {
                const err = error as Error;
                console.error(`❌ ${member.name}: ${err.message}`);
            }
        }
    }

    console.log(`\n✨ Added ${added} members to 2024-25`);
}

main();
