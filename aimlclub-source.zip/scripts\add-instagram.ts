// Add Instagram attribute to members collection
// Run with: npx tsx scripts/add-instagram.ts

import { Client, Databases } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);

async function main() {
    console.log("📝 Adding Instagram attribute to members collection...\n");

    try {
        await databases.createStringAttribute(
            "aiml-club-db",
            "members",
            "instagram",
            300,
            false
        );
        console.log("✅ Instagram attribute added successfully!");
    } catch (error: unknown) {
        const err = error as Error;
        if (err.message.includes("already exists")) {
            console.log("⏭️  Instagram attribute already exists");
        } else {
            console.error("❌ Error:", err.message);
        }
    }
}

main();
