import { Client, Storage, Databases, ID } from "node-appwrite";
import * as fs from "fs";
import * as path from "path";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";
const PROJECT_ID = "696f6e31002241c92438";
const ENDPOINT = "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = "aiml-club-db";
const MEMBERS_COLLECTION = "members";
const BUCKET_ID = "team-members";
const IMAGE_PATH = "C:\\Users\\Umesh\\Downloads\\Untitled design (1)\\Ananya Tomar.png";
const MEMBER_ID = "696f980c0010bf50bc50";

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const storage = new Storage(client);
const databases = new Databases(client);

async function main() {
    try {
        console.log("📤 Uploading image for Aanya Tomar...");
        const fileBuffer = fs.readFileSync(IMAGE_PATH);
        const blob = new Blob([fileBuffer], { type: "image/png" });
        const inputFile = new File([blob], "Ananya Tomar.png", { type: "image/png" });

        const uploadedFile = await storage.createFile(BUCKET_ID, ID.unique(), inputFile);
        const imageUrl = `${ENDPOINT}/storage/buckets/${BUCKET_ID}/files/${uploadedFile.$id}/view?project=${PROJECT_ID}`;

        console.log("update database...");
        await databases.updateDocument(DATABASE_ID, MEMBERS_COLLECTION, MEMBER_ID, {
            imageId: uploadedFile.$id,
            imageUrl: imageUrl
        });

        console.log("✅ Success! Aanya Tomar headshot updated.");
    } catch (error) {
        console.error("❌ Error:", error);
    }
}

main();
