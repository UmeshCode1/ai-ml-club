// Create storage buckets for team members and about section
// Run with: npx tsx scripts/create-storage-buckets.ts

import { Client, Storage, ID, Permission, Role } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const storage = new Storage(client);

const BUCKETS = [
    {
        id: "team-members",
        name: "Team Members",
        permissions: [
            Permission.read(Role.any()), // Public read
        ],
        fileSecurity: false,
        enabled: true,
        maximumFileSize: 5 * 1024 * 1024, // 5MB max
        allowedFileExtensions: ["jpg", "jpeg", "png", "webp", "gif"],
    },
    {
        id: "about",
        name: "About Section",
        permissions: [
            Permission.read(Role.any()), // Public read
        ],
        fileSecurity: false,
        enabled: true,
        maximumFileSize: 10 * 1024 * 1024, // 10MB max
        allowedFileExtensions: ["jpg", "jpeg", "png", "webp", "gif", "mp4", "webm"],
    },
];

async function main() {
    console.log("📦 Creating storage buckets...\n");

    for (const bucket of BUCKETS) {
        try {
            await storage.createBucket(
                bucket.id,
                bucket.name,
                bucket.permissions,
                bucket.fileSecurity,
                bucket.enabled,
                bucket.maximumFileSize,
                bucket.allowedFileExtensions
            );
            console.log(`✅ Created bucket: ${bucket.name} (${bucket.id})`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  Bucket already exists: ${bucket.name}`);
            } else {
                console.error(`❌ ${bucket.name}: ${err.message}`);
            }
        }
    }

    console.log("\n✨ Storage buckets ready!");
    console.log("\n📌 Upload images to these buckets in Appwrite Console:");
    console.log("   - team-members: Profile pictures for team members");
    console.log("   - about: Images for home page about section");
    console.log("\n🔗 Image URLs will be:");
    console.log("   https://fra.cloud.appwrite.io/v1/storage/buckets/{bucket-id}/files/{file-id}/view?project=696f6e31002241c92438");
}

main();
