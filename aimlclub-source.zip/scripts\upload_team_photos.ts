import { Client, Databases, Storage, ID, Query, Models } from "node-appwrite";
import { InputFile } from "node-appwrite/file";
import fs from "fs";
import path from "path";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";
const PROJECT_ID = "696f6e31002241c92438";
const DATABASE_ID = "aiml-club-db";
const COLLECTION_ID = "members";
const BUCKET_ID = "team-members";

interface MemberDocument extends Models.Document {
    name: string;
    role: string;
    imageUrl?: string;
    imageId?: string;
}

// Directory containing the photos
const FILES_DIR = "C:/Users/Umesh/Downloads/Untitled design";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);
const storage = new Storage(client);

// Levenshtein distance for fuzzy matching
function levenshtein(a: string, b: string): number {
    if (a.length === 0) return b.length;
    if (b.length === 0) return a.length;
    const matrix = [];
    for (let i = 0; i <= b.length; i++) matrix[i] = [i];
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }
    return matrix[b.length][a.length];
}

async function main() {
    console.log("🚀 Starting team photo upload process (v3 - Final with Resolution)...\n");

    // 1. Fetch all members
    console.log("fetching members...");
    const membersList = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_ID,
        [Query.limit(100)]
    );
    const members = membersList.documents as unknown as MemberDocument[];
    console.log(`✅ Found ${members.length} members in database.`);

    // 2. Read files from directory
    if (!fs.existsSync(FILES_DIR)) {
        console.error(`❌ Directory not found: ${FILES_DIR} `);
        return;
    }
    const files = fs.readdirSync(FILES_DIR).filter(file => {
        const ext = path.extname(file).toLowerCase();
        return ['.png', '.jpg', '.jpeg', '.webp'].includes(ext);
    });
    console.log(`✅ Found ${files.length} images in directory.`);

    const results = {
        updated: [] as string[],
        skippedAmbiguous: [] as string[],
        skippedNoMatch: [] as string[],
        errors: [] as string[]
    };

    // Special resolutions for known ambiguities
    const SPECIAL_RESOLUTIONS: { [key: string]: string } = {
        "Himanshu.png": "Himanshu Singh" // Default to Co-Head as per 'do it' instruction
    };

    // 3. Process each file
    for (const file of files) {
        const nameWithoutExt = path.parse(file).name.trim();
        const filePath = path.join(FILES_DIR, file);
        const fileNameLower = nameWithoutExt.toLowerCase();

        let matchingMembers: MemberDocument[] = [];

        // Check Special Resolution First
        if (SPECIAL_RESOLUTIONS[file]) {
            const target = members.find(m => m.name === SPECIAL_RESOLUTIONS[file]);
            if (target) {
                matchingMembers = [target];
                console.log(`💡 Applying special resolution for ${file} -> ${target.name}`);
            } else {
                console.log(`⚠️ Special resolution target not found: ${SPECIAL_RESOLUTIONS[file]} `);
            }
        } else {
            // Strategy 1: Exact or Prefix Match
            matchingMembers = members.filter(member => {
                const memberName = member.name.toLowerCase();
                return memberName === fileNameLower || memberName.startsWith(fileNameLower) || fileNameLower === memberName;
            });

            // Strategy 2: Fuzzy Match (if no direct match)
            if (matchingMembers.length === 0) {
                const bestMatches = members.map(m => ({
                    member: m,
                    dist: levenshtein(fileNameLower, m.name.toLowerCase())
                })).sort((a, b) => a.dist - b.dist);

                if (bestMatches[0].dist <= 3) {
                    const bestMatch = bestMatches[0];
                    const candidates = bestMatches.filter(m => m.dist === bestMatch.dist);
                    matchingMembers = candidates.map(c => c.member);
                    console.log(`💡 Fuzzy match for ${file}: found ${matchingMembers.map(m => m.name).join(", ")} (dist: ${bestMatch.dist})`);
                }
            }
        }

        if (matchingMembers.length === 0) {
            console.log(`⚠️  No matching member found for file: ${file} `);
            results.skippedNoMatch.push(file);
            continue;
        }

        // Check for duplicates (same name)
        const uniqueNames = [...new Set(matchingMembers.map(m => m.name))];
        let membersToUpdate: MemberDocument[] = [];

        if (uniqueNames.length === 1) {
            membersToUpdate = matchingMembers;
        } else {
            const exact = matchingMembers.find(m => m.name.toLowerCase() === nameWithoutExt.toLowerCase());
            if (exact) {
                const allExact = matchingMembers.filter(m => m.name.toLowerCase() === nameWithoutExt.toLowerCase());
                membersToUpdate = allExact;
                console.log(`   Resolved ambiguity for ${file} using Exact Match: ${exact.name} `);
            } else {
                console.log(`⚠️  Ambiguous match for file: ${file} -> ${uniqueNames.join(", ")} `);
                results.skippedAmbiguous.push(`${file} (${uniqueNames.join(", ")})`);
                continue;
            }
        }

        // Upload to Storage
        try {
            console.log(`   Uploading ${file} for ${membersToUpdate[0].name}...`);
            const inputFile = InputFile.fromPath(filePath, file);

            const uploadedFile = await storage.createFile(
                BUCKET_ID,
                ID.unique(),
                inputFile
            );

            const fileId = uploadedFile.$id;
            const imageUrl = `https://fra.cloud.appwrite.io/v1/storage/buckets/${BUCKET_ID}/files/${fileId}/view?project=${PROJECT_ID}`;

            // Update All Matched Documents
            for (const member of membersToUpdate) {
                await databases.updateDocument(
                    DATABASE_ID,
                    COLLECTION_ID,
                    member.$id,
                    {
                        imageId: fileId,
                        imageUrl: imageUrl
                    }
                );
            }
            console.log(`   ✅ Updated ${membersToUpdate.length} record(s) for ${membersToUpdate[0].name}`);
            results.updated.push(`${file} -> ${membersToUpdate[0].name}`);

        } catch (error: unknown) {
            const err = error as Error;
            console.error(`   ❌ Error processing ${file}: ${err.message}`);
            results.errors.push(`${file}: ${err.message}`);
        }
    }

    console.log("\n📊 Summary:");
    console.log(`✅ Updated: ${results.updated.length}`);
    console.log(`⚠️  Skipped (Ambiguous): ${results.skippedAmbiguous.length}`);
    if (results.skippedAmbiguous.length > 0) console.log(results.skippedAmbiguous);
    console.log(`⚠️  Skipped (No Match): ${results.skippedNoMatch.length}`);
    if (results.skippedNoMatch.length > 0) console.log(results.skippedNoMatch);
    console.log(`❌ Errors: ${results.errors.length}`);
}

main();
