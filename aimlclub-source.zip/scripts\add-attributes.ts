// Script to add all required attributes to Appwrite collections
// Run with: npx tsx scripts/add-attributes.ts

import { Client, Databases } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";

async function addMembersAttributes() {
    console.log("📝 Adding members collection attributes...\n");

    const attributes = [
        { key: "enrollmentNo", size: 20, required: false },
        { key: "contactNo", size: 20, required: false },
        { key: "team", size: 100, required: true },
    ];

    for (const attr of attributes) {
        try {
            await databases.createStringAttribute(
                DATABASE_ID,
                "members",
                attr.key,
                attr.size,
                attr.required
            );
            console.log(`✅ Added: ${attr.key}`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  Skipped: ${attr.key} (already exists)`);
            } else {
                console.error(`❌ Failed: ${attr.key} - ${err.message}`);
            }
        }
    }
}

async function addSubscriptionsAttributes() {
    console.log("\n📝 Adding subscriptions collection attributes...\n");

    const attributes = [
        { key: "name", size: 100, required: true },
        { key: "email", type: "email", required: true },
    ];

    for (const attr of attributes) {
        try {
            if (attr.type === "email") {
                await databases.createEmailAttribute(
                    DATABASE_ID,
                    "subscriptions",
                    attr.key,
                    attr.required
                );
            } else {
                await databases.createStringAttribute(
                    DATABASE_ID,
                    "subscriptions",
                    attr.key,
                    attr.size || 100,
                    attr.required
                );
            }
            console.log(`✅ Added: ${attr.key}`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  Skipped: ${attr.key} (already exists)`);
            } else {
                console.error(`❌ Failed: ${attr.key} - ${err.message}`);
            }
        }
    }
}

async function addEventsAttributes() {
    console.log("\n📝 Adding events collection attributes...\n");

    const stringAttrs = [
        { key: "title", size: 200, required: true },
        { key: "description", size: 2000, required: true },
        { key: "date", size: 50, required: true },
        { key: "venue", size: 200, required: true },
        { key: "imageId", size: 50, required: false },
        { key: "status", size: 20, required: true },
    ];

    for (const attr of stringAttrs) {
        try {
            await databases.createStringAttribute(
                DATABASE_ID,
                "events",
                attr.key,
                attr.size,
                attr.required
            );
            console.log(`✅ Added: ${attr.key}`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  Skipped: ${attr.key} (already exists)`);
            } else {
                console.error(`❌ Failed: ${attr.key} - ${err.message}`);
            }
        }
    }
}

async function addBlogAttributes() {
    console.log("\n📝 Adding blog collection attributes...\n");

    const stringAttrs = [
        { key: "title", size: 200, required: true },
        { key: "slug", size: 200, required: true },
        { key: "excerpt", size: 500, required: true },
        { key: "content", size: 50000, required: true },
        { key: "author", size: 100, required: true },
        { key: "imageId", size: 50, required: false },
    ];

    for (const attr of stringAttrs) {
        try {
            await databases.createStringAttribute(
                DATABASE_ID,
                "blog",
                attr.key,
                attr.size,
                attr.required
            );
            console.log(`✅ Added: ${attr.key}`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  Skipped: ${attr.key} (already exists)`);
            } else {
                console.error(`❌ Failed: ${attr.key} - ${err.message}`);
            }
        }
    }

    // Boolean attribute for published
    try {
        await databases.createBooleanAttribute(DATABASE_ID, "blog", "published", true);
        console.log(`✅ Added: published`);
    } catch (error: unknown) {
        const err = error as Error;
        if (err.message.includes("already exists")) {
            console.log(`⏭️  Skipped: published (already exists)`);
        } else {
            console.error(`❌ Failed: published - ${err.message}`);
        }
    }
}

async function addGalleryAttributes() {
    console.log("\n📝 Adding gallery collection attributes...\n");

    const stringAttrs = [
        { key: "title", size: 200, required: true },
        { key: "description", size: 500, required: false },
        { key: "imageId", size: 50, required: true },
        { key: "eventName", size: 200, required: false },
        { key: "category", size: 50, required: false },
    ];

    for (const attr of stringAttrs) {
        try {
            await databases.createStringAttribute(
                DATABASE_ID,
                "gallery",
                attr.key,
                attr.size,
                attr.required
            );
            console.log(`✅ Added: ${attr.key}`);
        } catch (error: unknown) {
            const err = error as Error;
            if (err.message.includes("already exists")) {
                console.log(`⏭️  Skipped: ${attr.key} (already exists)`);
            } else {
                console.error(`❌ Failed: ${attr.key} - ${err.message}`);
            }
        }
    }
}

async function main() {
    console.log("🔧 AIML Club - Adding Collection Attributes\n");
    console.log("=============================================\n");

    await addMembersAttributes();
    await addSubscriptionsAttributes();
    await addEventsAttributes();
    await addBlogAttributes();
    await addGalleryAttributes();

    console.log("\n=============================================");
    console.log("✨ Attribute setup complete!");
    console.log("\n⚠️  Note: Wait 30 seconds for Appwrite to process, then run:");
    console.log("   npx tsx scripts/setup-appwrite.ts");
}

main().catch(console.error);
