// Add year and status attributes to members collection
// Run with: npx tsx scripts/add-year-status.ts

import { Client, Databases } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";

async function addAttribute(name: string, size: number) {
    try {
        await databases.createStringAttribute(DATABASE_ID, "members", name, size, false);
        console.log(`✅ Added: ${name}`);
    } catch (error: unknown) {
        const err = error as Error;
        if (err.message.includes("already exists")) {
            console.log(`⏭️  ${name} already exists`);
        } else {
            console.error(`❌ ${name}: ${err.message}`);
        }
    }
}

async function main() {
    console.log("📝 Adding year and status attributes to members collection...\n");

    // year: e.g., "2024-25", "2025-26"
    await addAttribute("year", 10);

    // status: "active", "inactive", "alumni"
    await addAttribute("status", 20);

    console.log("\n✨ Done!");
    console.log("\n📌 Now update existing members with:");
    console.log("   - year: '2024-25' (or appropriate year)");
    console.log("   - status: 'active' / 'inactive' / 'alumni'");
}

main();
