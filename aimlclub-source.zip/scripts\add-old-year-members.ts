// Add team heads to 2024-25 year (old year)
// Run with: npx tsx scripts/add-old-year-members.ts

import { Client, Databases, ID } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const databases = new Databases(client);
const DATABASE_ID = "aiml-club-db";

// Team heads for 2024-25 (old year)
const OLD_YEAR_MEMBERS = [
    // Faculty
    { name: "Prof. Shamaila Khan", role: "Faculty Coordinator", team: "Faculty", email: "shamaila@octbhopal.ac.in", year: "2024-25", status: "active" },

    // Core Leadership
    { name: "Vishal Kumar", role: "President", team: "Core Leadership", email: "vishal.kumar@example.com", enrollmentNo: "0126AL231143", year: "2024-25", status: "active" },
    { name: "Umesh Patel", role: "Vice President", team: "Core Leadership", email: "umesh.code1@gmail.com", enrollmentNo: "0126AL231140", year: "2024-25", status: "active", linkedin: "https://linkedin.com/in/umeshpatel", github: "https://github.com/umeshcode1" },

    // Team Heads
    { name: "Gourav Jain", role: "Event Head", team: "Event & Operations", email: "gourav.j@example.com", year: "2024-25", status: "active" },
    { name: "Aarchi Sharma", role: "Event Co-Head", team: "Event & Operations", email: "aarchi.s@example.com", year: "2024-25", status: "active" },
    { name: "Sarvesh Sejwar", role: "Discipline Head", team: "Discipline", email: "sarvesh.s@example.com", year: "2024-25", status: "active" },
    { name: "Kinshuk Verma", role: "Technical Head", team: "Technical", email: "kinshuk.v@example.com", year: "2024-25", status: "active" },
    { name: "Nimisha Kumari", role: "Technical Co-Head", team: "Technical", email: "nimisha.k@example.com", year: "2024-25", status: "active" },
    { name: "Arnav Singh", role: "Anchoring Head", team: "Anchors & Stage", email: "arnav.s@example.com", year: "2024-25", status: "active" },
    { name: "Himanshu Singh", role: "Anchoring Co-Head", team: "Anchors & Stage", email: "himanshu.s@example.com", year: "2024-25", status: "active" },

    // PHOTOPIA Heads
    { name: "Avni Rawat", role: "PR Head", team: "Media - PR", email: "avni.r@example.com", year: "2024-25", status: "active" },
    { name: "Shambhavi", role: "Design Head", team: "Media - Design", email: "shambhavi@example.com", year: "2024-25", status: "active" },
    { name: "Prakhar Sahu", role: "Media Head", team: "Media - Editors", email: "prakhar.s@example.com", year: "2024-25", status: "active" },
];

async function main() {
    console.log("📝 Adding team heads to 2024-25 year...\n");

    let added = 0;
    let errors = 0;

    for (const member of OLD_YEAR_MEMBERS) {
        try {
            await databases.createDocument(DATABASE_ID, "members", ID.unique(), member);
            console.log(`✅ ${member.name} (${member.role})`);
            added++;
        } catch (error: unknown) {
            const err = error as Error;
            console.error(`❌ ${member.name}: ${err.message}`);
            errors++;
        }
    }

    console.log(`\n✨ Added ${added} members to 2024-25`);
    if (errors > 0) console.log(`⚠️  ${errors} errors`);
}

main();
