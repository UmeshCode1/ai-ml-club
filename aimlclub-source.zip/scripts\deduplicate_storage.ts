import { Client, Storage, Query, Models } from "node-appwrite";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";
const PROJECT_ID = "696f6e31002241c92438";
const BUCKET_ID = "team-members";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const storage = new Storage(client);

async function main() {
    console.log("🧹 Starting storage deduplication cleanup...\n");

    try {
        const allFiles: Models.File[] = [];
        const limit = 100;
        let offset = 0;

        // 1. Fetch ALL files
        while (true) {
            const response = await storage.listFiles(
                BUCKET_ID,
                [Query.limit(limit), Query.offset(offset)]
            );
            allFiles.push(...response.files);

            if (response.files.length < limit) break;
            offset += limit;
        }

        console.log(`✅ Found ${allFiles.length} total files.`);

        // 2. Group by Filename
        const fileGroups: Record<string, Models.File[]> = {};

        for (const file of allFiles) {
            if (!fileGroups[file.name]) {
                fileGroups[file.name] = [];
            }
            fileGroups[file.name].push(file);
        }

        // 3. Process Groups
        let deletedCount = 0;

        for (const fileName in fileGroups) {
            const files = fileGroups[fileName];

            if (files.length > 1) {
                // Sort by creation time descending (newest first)
                files.sort((a, b) => new Date(b.$createdAt).getTime() - new Date(a.$createdAt).getTime());

                // Keep files[0], delete the rest
                const toKeep = files[0];
                const toDelete = files.slice(1);

                console.log(`🔍 Duplicate: ${fileName} (${files.length} copies). Keeping ${toKeep.$id}. Deleting ${toDelete.length}...`);

                for (const file of toDelete) {
                    try {
                        await storage.deleteFile(BUCKET_ID, file.$id);
                        console.log(`   🗑️ Deleted ${file.$id}`);
                        deletedCount++;
                    } catch (err: unknown) {
                        const errorMessage = err instanceof Error ? err.message : "An unknown error occurred";
                        console.error(`   ❌ Failed to delete ${file.$id}: ${errorMessage}`);
                    }
                }
            }
        }

        console.log(`\n✨ Cleanup complete. Deleted ${deletedCount} duplicates.`);

    } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : "An unknown error occurred";
        console.error("❌ Error:", errorMessage);
    }
}

main();
