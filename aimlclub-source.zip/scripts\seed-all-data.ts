import { Client, Databases, ID, Query, Permission, Role, AppwriteException } from "node-appwrite";
import * as dotenv from "dotenv";
import * as path from "path";

// Load environment variables
dotenv.config({ path: path.resolve(process.cwd(), ".env.local") });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

if (!API_KEY) {
    console.error("APPWRITE_API_KEY is missing in .env.local");
    process.exit(1);
}

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);

// Helper for valid URLs
const toValidUrl = (p: string) => {
    if (!p) return "https://aimlclub.tech/images/placeholder.jpg";
    if (p.startsWith("http")) return p;
    // Normalize path
    const cleanPath = p.startsWith("/") ? p : `/${p}`;
    return `https://aimlclub.tech${cleanPath}`;
};

// Data
const galleryAlbums = [
    {
        eventName: "Expert Talk - Coding Thinker",
        description: "Insightful session on coding practices and tech industry insights",
        posterUrl: toValidUrl("/images/events/expert-talk.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-08-26",
        category: "Expert Talk",
        photoCount: 15,
        isVisible: true,
    },
    {
        eventName: "DSPL Session & Workshop",
        description: "Deep dive into Data Structures and Problem Solving Logic",
        posterUrl: toValidUrl("/images/events/dspl.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-09-15",
        category: "Workshop",
        photoCount: 20,
        isVisible: true,
    },
    {
        eventName: "Apfity Competition",
        description: "Exciting AI aptitude and fitness competition",
        posterUrl: toValidUrl("/images/events/apfity.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-10-20",
        category: "Competition",
        photoCount: 30,
        isVisible: true,
    },
    {
        eventName: "Codify Competition",
        description: "Coding competition to test programming skills",
        posterUrl: toValidUrl("/images/events/codify.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-11-14",
        category: "Competition",
        photoCount: 25,
        isVisible: true,
    },
    {
        eventName: "Expert Talk - Reinforcement Learning",
        description: "Expert session on Reinforcement Learning concepts and applications",
        posterUrl: toValidUrl("/images/events/rl-talk.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-11-25",
        category: "Expert Talk",
        photoCount: 12,
        isVisible: true,
    },
    {
        eventName: "WordPress Tour Workshop",
        description: "Complete workshop on website creation with WordPress",
        posterUrl: toValidUrl("/images/events/wordpress.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-12-13",
        category: "Workshop",
        photoCount: 18,
        isVisible: true,
    },
    {
        eventName: "Core Team Orientation",
        description: "Onboarding and orientation session for new core team members",
        posterUrl: toValidUrl("/images/events/orientation.jpg"),
        driveLink: "https://aimlclub.tech/drive",
        eventDate: "2025-12-30",
        category: "Orientation",
        photoCount: 10,
        isVisible: true,
    },
];

const blogPosts = [
    {
        title: "Welcome to AIML Club Blog",
        slug: "welcome-to-aiml-club",
        excerpt: "Introducing our new blog platform where we'll share tech insights, event recaps, and AI/ML tutorials.",
        content: "# Welcome to AIML Club Blog\n\nWe're excited to launch our official blog! Here, you'll find:\n\n- **Tech Tutorials**: Deep dives into AI, ML, and programming concepts\n- **Event Recaps**: Highlights from our workshops, competitions, and talks\n- **Industry Insights**: Latest trends in AI and technology\n- **Member Spotlights**: Stories from our amazing community\n\nStay tuned for more content!",
        author: "AIML Club Team",
        authorRole: "Core Team",
        category: "Announcements",
        tags: "welcome,aiml,blog,launch",
        readTime: 2,
        isPublished: true,
        isFeatured: true,
        publishedAt: "2025-08-09",
    },
    {
        title: "Introduction to Machine Learning",
        slug: "intro-to-machine-learning",
        excerpt: "A beginner-friendly guide to understanding the basics of Machine Learning and its applications.",
        content: "# Introduction to Machine Learning\n\nMachine Learning (ML) is a subset of Artificial Intelligence that enables computers to learn from data...\n\n## What is Machine Learning?\n\nMachine Learning is the science of getting computers to act without being explicitly programmed...\n\n## Types of ML\n\n1. **Supervised Learning**\n2. **Unsupervised Learning**\n3. **Reinforcement Learning**",
        author: "Tech Team",
        authorRole: "Content Writer",
        category: "AI & ML",
        tags: "machine learning,ai,tutorial,beginner",
        readTime: 5,
        isPublished: true,
        isFeatured: false,
        publishedAt: "2025-09-15",
    },
];

const events = [
    {
        title: "Expert Talk by Coding Thinker",
        description: "An insightful expert session on coding practices and tech industry insights by Coding Thinker. Learn from experienced professionals and enhance your programming skills.",
        date: "2025-08-26",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/expert-talk.jpg"),
        isUpcoming: false,
        category: "Expert Talk",
        duration: "1.5 hours",
        status: "completed"
    },
    {
        title: "DSPL Session",
        description: "Data Structures and Programming Logic session - A comprehensive learning experience to strengthen your fundamentals in DSA and logical programming.",
        date: "2025-09-10",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/dspl-session.jpg"),
        isUpcoming: false,
        category: "Session",
        duration: "2 hours",
        registrationLink: "https://drive.google.com/drive/folders/1xv3a9iCzqhP2mRNXrXFPtc2MdO4triam",
        status: "completed"
    },
    {
        title: "DSPL Workshop",
        description: "Two-day intensive hands-on workshop on Data Structures and Programming Logic.",
        date: "2025-09-11",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/dspl-workshop.jpg"),
        isUpcoming: false,
        category: "Workshop",
        duration: "2 days",
        registrationLink: "https://drive.google.com/drive/folders/1xv3a9iCzqhP2mRNXrXFPtc2MdO4triam",
        status: "completed"
    },
    {
        title: "Apfity Competition",
        description: "Apfity - The ultimate aptitude and coding competition.",
        date: "2025-10-13",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/apfity.jpg"),
        isUpcoming: false,
        category: "Competition",
        duration: "1 hour",
        registrationLink: "https://drive.google.com/drive/folders/1yEwEA1owqbw1So4HH01FjJaeSejo5XMo",
        status: "completed"
    },
    {
        title: "Codify - Coding Competition",
        description: "Codify - AIML Club's flagship coding competition.",
        date: "2025-11-10",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/codify.jpg"),
        isUpcoming: false,
        category: "Competition",
        duration: "1 hour",
        status: "completed"
    },
    {
        title: "Expert Talk on Reinforcement Learning",
        description: "Deep dive into Reinforcement Learning with industry experts.",
        date: "2025-11-29",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/rl-talk.jpg"),
        isUpcoming: false,
        category: "Expert Talk",
        duration: "1.5 hours",
        status: "completed"
    },
    {
        title: "WordPress Tour Workshop",
        description: "Complete WordPress workshop covering website creation.",
        date: "2025-12-13",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/wordpress.jpg"),
        isUpcoming: false,
        category: "Workshop",
        duration: "3 hours",
        status: "completed"
    },
    {
        title: "New Core Team Member Orientation",
        description: "Official onboarding and orientation session for new AIML Club core team members.",
        date: "2025-12-30",
        venue: "Oriental College of Technology, Bhopal",
        imageUrl: toValidUrl("/images/events/orientation.jpg"),
        isUpcoming: false,
        category: "Orientation",
        duration: "2 hours",
        status: "completed"
    }
];

async function seed() {
    console.log("🚀 Starting FINAL Data Seeding...\n");

    // 1. Gallery
    console.log("📸 Seeding Gallery...");
    for (const album of galleryAlbums) {
        try {
            await databases.createDocument(DATABASE_ID, "gallery", ID.unique(), album);
            console.log(`✅ ${album.eventName}`);
        } catch (e: any) {
            console.error(`❌ ${album.eventName}: ${e.message}`);
        }
    }

    // 2. Blog
    console.log("\n✍️ Seeding Blog...");
    for (const post of blogPosts) {
        try {
            await databases.createDocument(DATABASE_ID, "blog", ID.unique(), post);
            console.log(`✅ ${post.title}`);
        } catch (e: any) {
            console.error(`❌ ${post.title}: ${e.message}`);
        }
    }

    // 3. Events
    console.log("\n📅 Seeding Events...");
    for (const event of events) {
        try {
            await databases.createDocument(DATABASE_ID, "events", ID.unique(), event);
            console.log(`✅ ${event.title}`);
        } catch (e: any) {
            console.error(`❌ ${event.title}: ${e.message}`);
        }
    }

    console.log("\n✨ All data seeded successfully!");
}

seed().catch(console.error);
