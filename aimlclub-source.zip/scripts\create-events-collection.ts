import { Client, Databases, Permission, Role } from "node-appwrite";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

if (!API_KEY) {
    console.error("❌ APPWRITE_API_KEY not found in .env.local");
    process.exit(1);
}

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);

const COLLECTION_ID = "events";

async function createEventsCollection() {
    console.log("🚀 Creating Events collection...\n");

    try {
        try {
            await databases.deleteCollection(DATABASE_ID, COLLECTION_ID);
            console.log("🗑️  Deleted existing events collection");
        } catch (error: unknown) {
            // Check if the error is due to the collection not existing
            if (error instanceof Error && error.message.includes("Collection not found")) {
                console.log("📁 No existing events collection found");
            } else {
                // Re-throw other unexpected errors
                throw error;
            }
        }

        await databases.createCollection(
            DATABASE_ID,
            COLLECTION_ID,
            "Events",
            [
                Permission.read(Role.any()),
                Permission.create(Role.users()),
                Permission.update(Role.users()),
                Permission.delete(Role.users()),
            ]
        );
        console.log("✅ Created events collection");

        const attributes = [
            { name: "title", type: "string", size: 255, required: true },
            { name: "description", type: "string", size: 2000, required: true },
            { name: "date", type: "string", size: 50, required: true },
            { name: "time", type: "string", size: 50, required: false },
            { name: "venue", type: "string", size: 255, required: false },
            { name: "location", type: "string", size: 255, required: false },
            { name: "imageUrl", type: "url", required: false },
            { name: "registrationLink", type: "url", required: false },
            { name: "isUpcoming", type: "boolean", required: true, default: false },
            { name: "category", type: "string", size: 100, required: false },
            { name: "duration", type: "string", size: 100, required: false },
            { name: "status", type: "string", size: 50, required: false },
        ];

        for (const attr of attributes) {
            try {
                if (attr.type === "string") {
                    await databases.createStringAttribute(DATABASE_ID, COLLECTION_ID, attr.name, attr.size!, attr.required);
                } else if (attr.type === "url") {
                    await databases.createUrlAttribute(DATABASE_ID, COLLECTION_ID, attr.name, attr.required);
                } else if (attr.type === "boolean") {
                    await databases.createBooleanAttribute(DATABASE_ID, COLLECTION_ID, attr.name, attr.required, attr.default);
                }
                console.log(`  ✅ ${attr.name} `);
            } catch (err: unknown) {
                const errorMessage = err instanceof Error ? err.message : "An unknown error occurred";
                console.log(`  ⚠️  ${attr.name}: ${errorMessage} `);
            }
        }

        console.log("\n⏳ Waiting for attributes...");
        await new Promise(r => setTimeout(r, 4000));

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await databases.createIndex(DATABASE_ID, COLLECTION_ID, "date_idx", "key" as any, ["date"], ["desc"]);
        console.log("✅ Created date index");

        console.log("\n🎉 Events collection created successfully!");
    } catch (error: unknown) {
        console.error("❌ Error:", error instanceof Error ? error.message : error);
    }
}

createEventsCollection();
