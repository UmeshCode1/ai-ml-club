import { Client, Databases, Query } from "node-appwrite";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY || "");

const databases = new Databases(client);

async function clean() {
    console.log("Cleaning duplicates...");

    // Gallery
    console.log("\nCleaning Gallery...");
    const gallery = await databases.listDocuments(DATABASE_ID, "gallery", [Query.limit(100)]);
    const galleryNames = new Set();
    for (const doc of gallery.documents) {
        if (galleryNames.has(doc.eventName)) {
            await databases.deleteDocument(DATABASE_ID, "gallery", doc.$id);
            console.log(`🗑️  Deleted duplicate album: ${doc.eventName}`);
        } else {
            galleryNames.add(doc.eventName);
        }
    }

    // Blog
    console.log("\nCleaning Blog...");
    const blog = await databases.listDocuments(DATABASE_ID, "blog", [Query.limit(100)]);
    const blogSlugs = new Set();
    for (const doc of blog.documents) {
        if (blogSlugs.has(doc.slug)) {
            await databases.deleteDocument(DATABASE_ID, "blog", doc.$id);
            console.log(`🗑️  Deleted duplicate post: ${doc.title}`);
        } else {
            blogSlugs.add(doc.slug);
        }
    }

    // Events
    console.log("\nCleaning Events...");
    const events = await databases.listDocuments(DATABASE_ID, "events", [Query.limit(100)]);
    const eventTitles = new Set();
    for (const doc of events.documents) {
        if (eventTitles.has(doc.title)) {
            await databases.deleteDocument(DATABASE_ID, "events", doc.$id);
            console.log(`🗑️  Deleted duplicate event: ${doc.title}`);
        } else {
            eventTitles.add(doc.title);
        }
    }

    console.log("\nCleanup done.");
}

clean();
