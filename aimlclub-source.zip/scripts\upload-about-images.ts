// Upload images from D:\images\about to Appwrite about bucket
// Run with: npx tsx scripts/upload-about-images.ts

import { Client, Storage, ID } from "node-appwrite";
import * as fs from "fs";
import * as path from "path";

const API_KEY = "standard_095d47b994038e6ca09c0aa886b8e0628a8d24438f85cbd247e6c049f7c014e2ee66ac344d008c81bf10cad73c509666a996e8229d568c7d30eb012f693def8b385753a2b9c5c6f343af1765f9e9a7e7e90d063f18d86c90da26494032f114f4d974b95fdfbc4c51ccbfa97edb978a6f1fb57ae9ffa29c12b50d82a04d9bb068";

const client = new Client()
    .setEndpoint("https://fra.cloud.appwrite.io/v1")
    .setProject("696f6e31002241c92438")
    .setKey(API_KEY);

const storage = new Storage(client);
const BUCKET_ID = "about";
const IMAGES_DIR = "D:\\images\\about";
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB limit

async function main() {
    console.log("📤 Uploading images to 'about' bucket...\n");

    const files = fs.readdirSync(IMAGES_DIR);
    let uploaded = 0;
    let skipped = 0;

    for (const file of files) {
        const filePath = path.join(IMAGES_DIR, file);
        const stats = fs.statSync(filePath);

        // Skip if too large
        if (stats.size > MAX_FILE_SIZE) {
            console.log(`⏭️  Skipping (too large): ${file} (${(stats.size / 1024 / 1024).toFixed(1)}MB)`);
            skipped++;
            continue;
        }

        // Skip non-image files
        const ext = path.extname(file).toLowerCase();
        if (![".jpg", ".jpeg", ".png", ".webp", ".gif"].includes(ext)) {
            console.log(`⏭️  Skipping (not image): ${file}`);
            skipped++;
            continue;
        }

        try {
            // Read file as buffer and create a Blob
            const fileBuffer = fs.readFileSync(filePath);
            const blob = new Blob([fileBuffer], { type: `image/${ext.slice(1)}` });
            const inputFile = new File([blob], file, { type: `image/${ext.slice(1)}` });

            await storage.createFile(BUCKET_ID, ID.unique(), inputFile);
            console.log(`✅ Uploaded: ${file}`);
            uploaded++;
        } catch (error: unknown) {
            const err = error as Error;
            console.error(`❌ ${file}: ${err.message}`);
        }
    }

    console.log(`\n✨ Done! Uploaded ${uploaded} images, skipped ${skipped}`);
}

main();
