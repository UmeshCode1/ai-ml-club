/**
 * Script to create the Gallery Albums collection in Appwrite
 * Run with: npx ts-node scripts/create-gallery-collection.ts
 */

import { Client, Databases, Permission, Role } from "node-appwrite";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

if (!API_KEY) {
    console.error("❌ APPWRITE_API_KEY not found in .env.local");
    process.exit(1);
}

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY);

const databases = new Databases(client);

const COLLECTION_ID = "gallery";

async function createGalleryCollection() {
    console.log("🚀 Creating Gallery Albums collection...\n");

    try {
        // Try to delete existing collection first
        try {
            await databases.deleteCollection(DATABASE_ID, COLLECTION_ID);
            console.log("🗑️  Deleted existing gallery collection");
        } catch {
            console.log("📁 No existing gallery collection found");
        }

        // Create new collection
        await databases.createCollection(
            DATABASE_ID,
            COLLECTION_ID,
            "Gallery Albums",
            [
                Permission.read(Role.any()),
                Permission.create(Role.users()),
                Permission.update(Role.users()),
                Permission.delete(Role.users()),
            ]
        );
        console.log("✅ Created gallery collection");

        // Create attributes
        const attributes = [
            { name: "eventName", type: "string", size: 255, required: true },
            { name: "description", type: "string", size: 1000, required: false },
            { name: "posterUrl", type: "url", required: true },
            { name: "driveLink", type: "url", required: true },
            { name: "eventDate", type: "string", size: 50, required: true },
            { name: "category", type: "string", size: 100, required: false },
            { name: "photoCount", type: "integer", required: false, min: 0, max: 10000, default: 0 },
            { name: "isVisible", type: "boolean", required: false, default: true },
        ];

        for (const attr of attributes) {
            try {
                if (attr.type === "string") {
                    await databases.createStringAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.size!,
                        attr.required
                    );
                } else if (attr.type === "url") {
                    await databases.createUrlAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.required
                    );
                } else if (attr.type === "integer") {
                    await databases.createIntegerAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.required,
                        attr.min,
                        attr.max,
                        attr.default
                    );
                } else if (attr.type === "boolean") {
                    await databases.createBooleanAttribute(
                        DATABASE_ID,
                        COLLECTION_ID,
                        attr.name,
                        attr.required,
                        attr.default
                    );
                }
                console.log(`  ✅ Created attribute: ${attr.name}`);
            } catch (error: unknown) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                console.log(`  ⚠️  Attribute ${attr.name}: ${errorMessage}`);
            }
        }

        // Wait for attributes to be ready
        console.log("\n⏳ Waiting for attributes to be ready...");
        await new Promise(resolve => setTimeout(resolve, 3000));

        // Create indexes
        try {
            await databases.createIndex(
                DATABASE_ID,
                COLLECTION_ID,
                "eventDate_idx",
                "key",
                ["eventDate"],
                ["desc"]
            );
            console.log("✅ Created eventDate index");
        } catch (error: unknown) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            console.log(`⚠️  Index: ${errorMessage}`);
        }

        try {
            await databases.createIndex(
                DATABASE_ID,
                COLLECTION_ID,
                "isVisible_idx",
                "key",
                ["isVisible"]
            );
            console.log("✅ Created isVisible index");
        } catch (error: unknown) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            console.log(`⚠️  Index: ${errorMessage}`);
        }

        console.log("\n🎉 Gallery Albums collection created successfully!");
        console.log("\n📝 Collection Schema:");
        console.log("   - eventName (string, required): Event/Album name");
        console.log("   - description (string): Album description");
        console.log("   - posterUrl (url, required): Poster/cover image URL");
        console.log("   - driveLink (url, required): Google Drive folder link");
        console.log("   - eventDate (string, required): Event date (YYYY-MM-DD)");
        console.log("   - category (string): Category (Workshop, Competition, etc.)");
        console.log("   - photoCount (integer): Number of photos in album");
        console.log("   - isVisible (boolean): Show on website (default: true)");

    } catch (error) {
        console.error("❌ Error creating collection:", error);
    }
}

createGalleryCollection();
