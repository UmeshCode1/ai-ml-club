import { Client, Databases } from "node-appwrite";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const PROJECT_ID = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID || "696f6e31002241c92438";
const ENDPOINT = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || "https://fra.cloud.appwrite.io/v1";
const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID || "aiml-club-db";
const API_KEY = process.env.APPWRITE_API_KEY;

const client = new Client()
    .setEndpoint(ENDPOINT)
    .setProject(PROJECT_ID)
    .setKey(API_KEY || "");

const databases = new Databases(client);

async function fix() {
    console.log("Adding missing isUpcoming attribute to events...");
    try {
        await databases.createBooleanAttribute(DATABASE_ID, "events", "isUpcoming", true, false);
        console.log("✅ Added isUpcoming");
        console.log("Waiting 5s...");
        await new Promise(r => setTimeout(r, 5000));
    } catch (e: unknown) {
        if (e instanceof Error) {
            console.log("⚠️ " + e.message);
        } else {
            console.log("⚠️ An unknown error occurred");
        }
    }
}

fix().catch(console.error);
